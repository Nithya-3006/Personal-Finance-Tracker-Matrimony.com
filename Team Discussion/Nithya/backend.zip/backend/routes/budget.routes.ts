import express from 'express';
import {
  createBudget,
  getAllBudgets,
  updateBudget,
  deleteBudget
} from '../controllers/budget.controller';

const router = express.Router();

router.get('/budgets', getAllBudgets);
router.post('/budget', createBudget);
router.put('/budget/:id', updateBudget);
router.delete('/budget/:id', deleteBudget);

export default router;
