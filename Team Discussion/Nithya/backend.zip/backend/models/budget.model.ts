export interface Budget {
    id?: number;
    category: string;
    limit: number;
  }