import { Request, Response } from 'express';
import { db } from '../db';
import { Budget } from '../models/budget.model';

// Get all budgets
export const getAllBudgets = (req: Request, res: Response) => {
  db.query('SELECT * FROM budget', (err, results) => {
    if (err) return res.status(500).json({ error: err });
    res.json(results);
  });
};

// Create a budget
export const createBudget = (req: Request, res: Response) => {
  const { category, limit } = req.body;
  if (!category || limit == null) {
    return res.status(400).json({ error: 'Category and limit are required' });
  }

  const query = 'INSERT INTO budget (category, `limit`) VALUES (?, ?)';
  db.query(query, [category, limit], (err, result: mysql2.OkPacket) => {  // Type result as OkPacket
    if (err) return res.status(500).json({ error: err });
    res.status(201).json({ message: 'Budget created', id: result.insertId });
  });
};

// Update budget
export const updateBudget = (req: Request, res: Response) => {
  const { id } = req.params;
  const { category, limit } = req.body;

  const query = 'UPDATE budget SET category = ?, `limit` = ? WHERE id = ?';
  db.query(query, [category, limit, id], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: 'Budget updated' });
  });
};

// Delete budget
export const deleteBudget = (req: Request, res: Response) => {
  const { id } = req.params;

  db.query('DELETE FROM budget WHERE id = ?', [id], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: 'Budget deleted' });
  });
};
import mysql2 from 'mysql2';