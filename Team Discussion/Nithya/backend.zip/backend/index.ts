import express from 'express';
import cors from 'cors';
import budgetRoutes from './routes/budget.routes';

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

app.use('/api', budgetRoutes);

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
